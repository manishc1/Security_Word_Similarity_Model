// TregexMatcher
// Copyright (c) 2004-2007 The Board of Trustees of
// The Leland Stanford Junior University. All Rights Reserved.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//
// For more information, bug reports, fixes, contact:
//    Christopher Manning
//    Dept of Computer Science, Gates 1A
//    Stanford CA 94305-9010
//    USA
//    Support/Questions: parser-user@lists.stanford.edu
//    Licensing: parser-support@lists.stanford.edu
//    http://www-nlp.stanford.edu/software/tregex.shtml

package edu.stanford.nlp.trees.tregex;

import edu.stanford.nlp.io.NumberRangesFileFilter;
import edu.stanford.nlp.trees.DiskTreebank;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeReaderFactory;
import edu.stanford.nlp.trees.PennTreeReaderFactory;
import edu.stanford.nlp.trees.NPTmpRetainingTreeNormalizer;
import edu.stanford.nlp.util.StringUtils;
import java.io.File;
import java.io.FileFilter;
import java.util.*;

/**
 * A TregexMatcher can be used to match a {@link TregexPattern} against a {@link edu.stanford.nlp.trees.Tree}.
 * <p/>
 * <p> Usage should to be the same as {@link java.util.regex.Matcher}.
 * <p/>
 * <p> @author Galen Andrew
 */
public abstract class TregexMatcher {
  final Tree root;
  Tree tree;
  Map<String, Tree> namesToNodes;
  VariableStrings variableStrings;


  // these things are used by "find"
  Iterator<Tree> findIterator;
  Tree findCurrent;

  TregexMatcher(Tree root, Tree tree, Map<String, Tree> namesToNodes, VariableStrings variableStrings) {
    this.root = root;
    this.tree = tree;
    this.namesToNodes = namesToNodes;
    this.variableStrings = variableStrings;
  }

  /**
   * Resets the matcher so that its search starts over.
   */
  public void reset() {
    findIterator = null;
    namesToNodes.clear();
  }

  /**
   * Resets the matcher to start searching on the given tree for matching subexpressions
   */
  void resetChildIter(Tree tree) {
    this.tree = tree;
    resetChildIter();
  }

  /**
   * Resets the matcher to restart search for matching subexpressions
   */
  void resetChildIter() {
  }

  /**
   * Does the pattern match the tree?  It's actually closer to java.util.regex's
   * "lookingAt" in that the root of the tree has to match the root of the pattern
   * but the whole tree does not have to be "accounted for".  Like with lookingAt
   * the beginning of the string has to match the pattern, but the whole string
   * doesn't have to be "accounted for".
   *
   * @return whether the tree matches the pattern
   */
  public abstract boolean matches();

  /** Rests the matcher and tests if it matches on the tree when rooted at <code>node</code>.
   * @param node
   * @return whether the matcher matches at node
   */
  public boolean matchesAt(Tree node) {
    resetChildIter(node);
    return matches();
  }

  /**
   * Get the last matching tree -- that is, the tree node that matches the root node of the pattern.
   * Returns null if there has not been a match.
   *
   * @return last match
   */
  public abstract Tree getMatch();


  /**
   * Find the next match of the pattern on the tree
   *
   * @return whether there is a match somewhere in the tree
   */
  public boolean find() {
    if (findIterator == null) {
      findIterator = root.iterator();
    }
    if (findCurrent != null && matches()) {
      return true;
    }
    while (findIterator.hasNext()) {
      findCurrent = findIterator.next();
      resetChildIter(findCurrent);
      if (matches()) {
        return true;
      }
    }
    return false;
  }

  /**
   * Find the next match of the pattern on the tree such that the matching node (that is, the tree node matching the
   * root node of the pattern) differs from the previous matching node.
   * @return true iff another matching node is found.
   */
  public boolean findNextMatchingNode() {
    Tree lastMatchingNode = getMatch();
    while(find()) {
      if(getMatch() != lastMatchingNode)
        return true;
    }
    return false;
  }

  /**
   * Returns the node labeled with <code>name</code> in the pattern.
   *
   * @param name the name of the node, specified in the pattern.
   * @return node labeled by the name
   */
  public Tree getNode(String name) {
    return namesToNodes.get(name);
  }

  /**
   * Look at a bunch of trees and tell where TreePattern and TregexPattern
   * differ at all.  Use the -p <pattern> option for hand-specifying the
   * pattern.  This was intended for debugging TregexPattern against
   * TreePattern, and not for use by regular users, who should look at the
   * main method of TregexPattern.
   *
   * @param args TreebankPath, RangesFilter
   * @throws Exception
   */
  @SuppressWarnings({"UnnecessaryBoxing"})
  public static void main(String[] args) throws Exception {
    if (args.length < 2) {
      System.err.println("usage: TregexMatcher treebank numberRanges [-p pattern] [-print]");
      return;
    }
    Map<String,Integer> flagMap = new HashMap<String, Integer>();
    flagMap.put("-p", Integer.valueOf(1));
    Map<String,String[]> argsMap = StringUtils.argsToMap(args, flagMap);
    args = argsMap.get(null);
    String s = "VP < VBZ";
    if (argsMap.keySet().contains("-p")) {
      s = (argsMap.get("-p"))[0];
    }
    TregexPattern tregexPattern = TregexPattern.compile(s);

    FileFilter testFilt = new NumberRangesFileFilter(args[1], true);
    TreeReaderFactory trf = new PennTreeReaderFactory(new NPTmpRetainingTreeNormalizer());
    DiskTreebank testTreebank = new DiskTreebank(trf);
    testTreebank.loadPath(new File(args[0]), testFilt);

    TreePattern treePattern = TreePattern.compile(s); // null;

    boolean print = argsMap.keySet().contains("-print");

    for (Tree root : testTreebank) {
      TregexMatcher tregexMatcher = tregexPattern.matcher(root);
      TreeMatcher treeMatcher = treePattern.matcher(root);
      Tree lastTreeMatch = null;
      // a workaround to test tregexMatcher given that treeMatcher is now returning each tree twice
      List<Tree> tregexMatchedTrees = new ArrayList<Tree>();
      List<Tree> treeMatchedTrees = new ArrayList<Tree>();
      while (treeMatcher.find()) {
        Tree treeMatchedTree = treeMatcher.getMatch();
        if (treeMatchedTree == lastTreeMatch) {
          continue;
        }
        treeMatchedTrees.add(treeMatchedTree);
        lastTreeMatch = treeMatchedTree;
      }
      while (tregexMatcher.find()) {
        Tree tregexMatchedTree = tregexMatcher.getMatch();
        tregexMatchedTrees.add(tregexMatchedTree);
      }
      if (!tregexMatchedTrees.equals(treeMatchedTrees)) {
        System.out.println("Disagreement");
        if (print) {
          System.out.println("TreeMatcher found " + treeMatchedTrees.size() + " matches:");
          for (Tree tree : treeMatchedTrees) {
            tree.pennPrint();
          }
          System.out.println("TregexMatcher found " + tregexMatchedTrees.size() + " matches:");
          for (Tree tree : tregexMatchedTrees) {
            tree.pennPrint();
          }
        }
      }
    }
  }
}
