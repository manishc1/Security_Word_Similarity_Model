package edu.stanford.nlp.trees;

public interface TreebankTransformer {

  public MemoryTreebank transformTrees(Treebank tb);

}
