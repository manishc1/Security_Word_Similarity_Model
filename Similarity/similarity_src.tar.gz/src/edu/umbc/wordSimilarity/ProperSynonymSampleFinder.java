package edu.umbc.wordSimilarity;

import java.util.HashSet;

import edu.smu.tspell.wordnet.Synset;
import edu.smu.tspell.wordnet.WordNetDatabase;

public class ProperSynonymSampleFinder {

	public CoOccurModelByArrays model;
	public int FrequencyLimitStrict = 500000;
	public int FrequencyLimitWeak = 100000;
	WordNetDatabase database;
	public String pos;
	public HashSet<String> synonymPairs;
	
	public ProperSynonymSampleFinder(String word_type) {
		// TODO Auto-generated constructor stub
		pos = word_type.toLowerCase();
		model = new CoOccurModelByArrays("/home/lushan1/nlp/model/Gutenberg2010/0221/Gutenberg2010AllW21");
		System.setProperty("wordnet.database.dir", "/opt/WordNet-3.0/dict/");
		database = WordNetDatabase.getFileInstance();
		synonymPairs = new HashSet<String>();
	}

	public int processByWordNet(){
		
		String[] vocabulary = model.vocabulary; 
		
		for (String word : vocabulary){
			
			if (word.length() < 4) continue;
			
			boolean IsNormalWord = true;
			for (int index=0; index < word.length(); index++){
				if (!Character.isLowerCase(word.charAt(index))){
					IsNormalWord = false;
					break;
				}
			}
			
			if (!IsNormalWord) continue;
			
			
			boolean HaveOtherPOS = false;
			Synset[] synsets = database.getSynsets(word);
			
			for (Synset synset : synsets){
				if (!synset.getType().toString().equals(pos)){
					HaveOtherPOS = true;
					break;
				}
			}
			
			if (HaveOtherPOS) continue;
			
			int maximumCount = 0;
			int place = 0;
			int sumOfCount = 0;
			
			for (int i = 0; i < synsets.length; i++){
				
				int tagCount = synsets[i].getTagCount(word);
				
				if (tagCount > maximumCount){
					maximumCount = tagCount;
					place = i;
				}
				
				sumOfCount += tagCount;
			}
			
			if ((double)maximumCount / sumOfCount < 0.8 )
				continue;

			String[] synonymousWords = synsets[place].getWordForms();
			
			for (String synonym : synonymousWords){
				
				if (model.index(synonym) < 0)
					continue;
				
				if (synonym.length() < 4) continue;
				
				boolean synonym_IsNormalWord = true;
				for (int index=0; index < synonym.length(); index++){
					if (!Character.isLowerCase(synonym.charAt(index))){
						synonym_IsNormalWord = false;
						break;
					}
				}
				
				if (!synonym_IsNormalWord) continue;
				
				boolean synonym_HaveOtherPOS = false;
				Synset[] synonym_Synsets = database.getSynsets(synonym);
				
				for (Synset synset : synonym_Synsets){
					if (!synset.getType().toString().equals(pos)){
						synonym_HaveOtherPOS = true;
						break;
					}
				}
				
				if (synonym_HaveOtherPOS) continue;
				
				int synonym_maximumCount = 0;
				int synonym_sumOfCount = 0;
				
				for (int i = 0; i < synonym_Synsets.length; i++){
					
					int tagCount = synonym_Synsets[i].getTagCount(word);
					
					if (tagCount > synonym_maximumCount){
						synonym_maximumCount = tagCount;
					}
					
					synonym_sumOfCount += tagCount;
				}
				
				if ((double)synonym_maximumCount / synonym_sumOfCount < 0.8 )
					continue;				
				
				if (model.getFrequency(word) < model.totalWords / FrequencyLimitStrict && model.getFrequency(synonym) < model.totalWords / FrequencyLimitStrict)
					continue;
					
				if (model.getFrequency(word) < model.totalWords / FrequencyLimitWeak || model.getFrequency(synonym) < model.totalWords / FrequencyLimitWeak)
					continue;
				
				String synonym_pair;
				
				if (synonym)
				
			}
			
			
		}
		
		return 0;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
